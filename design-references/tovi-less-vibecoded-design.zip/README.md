# TOVI (WebView build of the interactive prototype)
Push this folder to a GitHub repo. Actions > "Build APK" > download the `TOVI-debug-apk` artifact.
The UI lives in app/src/main/assets/preview.html.
